﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
    public class Barn
    {
        
        public string color;
        public string inside;
        public string numHorses;

        public void Attributes()
        {
            this.color = "red as can be";
            this.inside = "horses within these stalls";
            this.numHorses = "30";
        }
        public Barn()
        {
            Attributes();
        }
    }
}
