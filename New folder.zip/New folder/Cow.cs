﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
    public class Cow
    {
        public string cowColor;
        public string activity;
        public string sound;
        public string eats;

        public void Attributes()
        {
            
            this.eats = "hay and grass";
            this.activity = "chew and chew";
            this.sound = "Moo Moo";
            this.cowColor = "white with spots that are brown or black";
        }
        public Cow()
        {
            Attributes();
        }
       
    }
}
