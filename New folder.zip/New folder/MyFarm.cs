﻿using System;

namespace MyFarm
{


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n\tMyFarm.Program.Main()\n");

            Barn barn = new Barn();
            
            Console.WriteLine($"When you first drive in you see a barn that's {barn.color}");
            Console.WriteLine($"Walk in closer, inside these walls and you will notice {barn.inside}");
            Console.WriteLine($"You think this is cool, you act flirty, but then you realize there are {barn.numHorses}");

            Cow thecow = new Cow();

            Console.WriteLine($"\nI can be {thecow.cowColor}");
            Console.WriteLine($"I like to eat {thecow.eats} for a snack");
            Console.WriteLine($"I eat when I can, and I {thecow.activity}");
            Console.WriteLine($"And when I don't eat, I say {thecow.sound}!");

            Goat thegoat = new Goat();
            Console.WriteLine($"\nThe goat on the farm is {thegoat.goatColor}");
            Console.WriteLine($"He goes by the name {thegoat.goatName}");
            Console.WriteLine($"When he's not given {thegoat.snacks} for a snack");
            Console.WriteLine($"I would watch my back for a surpise {thegoat.goatAction}");

            Pig thepig = new Pig();
            Console.WriteLine($"\nBehold the pig!");
            Console.WriteLine($"It's very {thepig.size}");
            Console.WriteLine($"Its color is {thepig.pigColor}");
            Console.WriteLine($"It's {thepig.personality}, I think");
            Console.WriteLine($"Its tail is a beaut");
            Console.WriteLine($"So curly and cute");
            Console.WriteLine($"And on the farm");
            Console.WriteLine($"It {thepig.pigSound} with charm");

            Console.ReadLine();

        }
    }
}

