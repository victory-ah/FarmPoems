﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
    public class Pig
    {
        public string pigSound;
        public string size;
        public string personality;
        public string pigColor;


        public void Attributes()
        {
            this.pigSound = "oinks";
            this.size = "big";
            this.personality = "nice";
            this.pigColor = "pink";
        }

        public Pig()
        {
            Attributes();   
        }

    }
}

       
         



