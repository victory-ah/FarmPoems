﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarm
{
    public class Goat
    {
        public string goatColor;
        public string snacks;
        public string goatName;
        public string goatAction;

        public void Attributes()
        {
            this.snacks = "tacos";
            this.goatColor = "tan";
            this.goatName = "Dan";
            this.goatAction = "attack";

        }

        public Goat()
        {
            Attributes();
        }
        
    }
}
